#include <QCoreApplication>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    for(int a = 0; a < 10; a++){
        qDebug("Test");
    }

        return a.exec();
}

